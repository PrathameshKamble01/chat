import fetch from "node-fetch";

const apiKey = "0ffb3a4a5ceb57fc41b71d312e51f86b";
const url = `https://api.openweathermap.org/data/2.5/weather?q=mumbai&units=metric&appid=${apiKey}`;


fetch(url)
.then((response) => {
    if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status} - ${response.statusText}`);
    }
    return response.json();
})
.then((data) => console.log(data))
.catch((err) => console.error("Error:", err.message));